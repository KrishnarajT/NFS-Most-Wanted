import React from "react";
import "./Button.css";
const Button = () => {
  return (
    <div>
      <div class="mybtn">
        <div class="btn">
          <a href="#">Read more 1</a>
        </div>
      </div>
    </div>
  );
};

export default Button;
