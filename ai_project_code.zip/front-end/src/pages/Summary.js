import React from "react";
import Navbar from "../Components/Navbar/Navbar";
import Loading from "../Components/Loading/Loading";
const Summary = () => {
  return (
    <div>
      <Navbar />
      <Loading />
    </div>
  );
};

export default Summary;
