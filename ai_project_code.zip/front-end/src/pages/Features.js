import React from "react";
import Navbar from "../Components/Navbar/Navbar";
import Timeline from "../Components/Timeline/Timeline";
const Features = () => {
  return (
    <div>
      <Navbar />
      <Timeline />
    </div>
  );
};

export default Features;
